package completions

import (
    "encoding/json"
    "os"
    "os/exec"
    "path/filepath"
    "time"
    "github.com/rsteube/carapace"
    "github.com/rsteube/carapace/pkg/action"
    "github.com/spf13/cobra"
)

func registerS3(cmd *cobra.Command) {
    carapace.Gen(cmd).PositionalCompletion(
        action.ActionCallback(func(c carapace.Context) carapace.Action {
            if len(c.Args) >= 2 && c.Args[0] == "s3api" && c.Args[1] == "list-buckets" {
                return s3Completion(c.Args)
            }
            return carapace.ActionValues()
        }),
    )
}

func s3Completion(args []string) carapace.Action {
    profile := "default"
    region := "us-east-1"
    for i, arg := range args {
        if arg == "--profile" && i+1 < len(args) {
            profile = args[i+1]
        }
        if arg == "--region" && i+1 < len(args) {
            region = args[i+1]
        }
    }

    cacheDir := filepath.Join(os.Getenv("HOME"), ".cache", "aws-smart", "s3_buckets", profile, region)
    cacheFile := filepath.Join(cacheDir, "s3_buckets.json")
    os.MkdirAll(cacheDir, 0755)

    var entries [][]string

    fi, err := os.Stat(cacheFile)
    if err == nil && time.Since(fi.ModTime()) < 5*time.Minute {
        data, _ := os.ReadFile(cacheFile)
        _ = json.Unmarshal(data, &entries)
    } else {
        out, err := exec.Command("aws", "s3api", "list-buckets",
            "--profile", profile,
            "--region", region,
            "--query", "Buckets[].[Name, CreationDate]",
            "--output", "json").Output()

        if err != nil {
            return carapace.ActionMessage("Erro ao consultar AWS")
        }
        _ = json.Unmarshal(out, &entries)
        _ = os.WriteFile(cacheFile, out, 0644)
    }

    values := make([]string, 0)
    for _, pair := range entries {
        if len(pair) > 0 {
            id := pair[0]
            desc := "(sem info)"
            if len(pair) > 1 {
                desc = pair[1]
            }
            values = append(values, id, desc)
        }
    }
    return carapace.ActionValuesDescribed(values...)
}
