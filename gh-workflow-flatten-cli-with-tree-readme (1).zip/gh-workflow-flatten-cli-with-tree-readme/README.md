# gh-workflow-flatten

Ferramenta CLI para "achatar" workflows GitHub que usam `uses:` recursivos, resolvendo e unificando todos os arquivos `.yml` envolvidos em um único documento, com opções de visualização gráfica e em árvore.

## 🧩 Funcionalidades

- Clonagem recursiva sob demanda de workflows usados (`uses:`)
- Resolução de dependências `reusable` e `nested`
- Exportação:
  - YAML resolvido
  - Árvore `.dot` (Graphviz)
  - Árvore interativa `.html`
- Cache inteligente para evitar reprocessamentos
- Preview da árvore direto no terminal

## 🚀 Instalação

Após extrair o pacote:

```bash
pip install .
```

Isso disponibiliza o comando:

```bash
gh-workflow-flatten --help
```

## 💡 Uso

```bash
gh-workflow-flatten ./meu-repo   --output resolved_workflows.yml   --dot workflow_tree.dot   --html workflow_tree.html   --preview
```

### Argumentos

- `repo_path` — Caminho para o repositório local
- `--output` — Caminho para salvar o YAML resolvido
- `--dot` — Exporta árvore `.dot` para visualização via Graphviz
- `--html` — Exporta árvore interativa em HTML
- `--preview` — Mostra a árvore no terminal
- `--no-cache` — Desativa o uso de cache
- `--clear-cache` — Limpa o cache existente

## 🧰 Exemplo de visualização

- Para renderizar a árvore em imagem:

```bash
dot -Tpng workflow_tree.dot -o workflow_tree.png
```

- Para abrir o HTML gerado:

```bash
xdg-open workflow_tree.html  # ou open no macOS
```

## 📂 Estrutura esperada dos workflows

```
.github/workflows/*.yml
```

## 📦 Requisitos

- Python 3.7+
- `graphviz` instalado no sistema (para gerar imagens)

---

MIT License • Desenvolvido com ☕ por você

### 🗂️ Modo `--extract-tree`

Cria uma pasta `resolved/` contendo:

- O workflow original do repositório
- Todos os workflows referenciados via `uses:`
- Estrutura de pastas correspondendo à origem dos repositórios
- Todos os `uses:` reescritos para caminhos locais

#### Exemplo:

```bash
gh-workflow-flatten ./repo --extract-tree
```

Isso irá gerar:

```
resolved/
├── main/
│   └── deploy.yml
├── orgB/action-repo/
│   └── action.yml
├── orgC/reusable/
│   └── build.yml
```

Dentro dos arquivos `.yml`, as referências `uses:` são reescritas assim:

```yaml
uses: orgB/action-repo/action.yml  # caminho local
```