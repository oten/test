import shutil
from pathlib import Path
from utils import load_yaml, extract_uses, parse_uses

def rewrite_uses(yaml_data, uses_map):
    def replace(node):
        if isinstance(node, dict):
            for k, v in node.items():
                if k == "uses" and v in uses_map:
                    node[k] = uses_map[v]
                else:
                    replace(v)
        elif isinstance(node, list):
            for item in node:
                replace(item)
    replace(yaml_data)
    return yaml_data

def export_resolved_tree(resolved_entries, output_root="resolved"):
    out_root = Path(output_root)
    out_root.mkdir(parents=True, exist_ok=True)

    uses_map = {}
    seen = set()

    for entry in resolved_entries:
        original = Path(entry["workflow_file"])
        source_path = original if original.exists() else Path(".") / original

        local_path = f"{entry['from_repo']}/{original.name}"
        out_path = out_root / local_path
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # Mapear uses para caminho local relativo
        uses_map[entry["uses"]] = str(Path(local_path).as_posix())

        if out_path in seen:
            continue
        seen.add(out_path)

        # Carregar, reescrever e salvar
        try:
            data = load_yaml(source_path)
            new_data = rewrite_uses(data, uses_map)
            with open(out_path, "w", encoding="utf-8") as f:
                import yaml
                yaml.dump(new_data, f, sort_keys=False)
        except Exception as e:
            print(f"⚠️ Erro processando {source_path}: {e}")

    print(f"📂 Árvore resolvida exportada em: {output_root}")