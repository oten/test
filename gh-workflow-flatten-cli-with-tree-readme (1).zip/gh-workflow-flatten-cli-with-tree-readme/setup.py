from setuptools import setup, find_packages

setup(
    name="gh-workflow-flatten",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "PyYAML",
        "graphviz"
    ],
    entry_points={
        "console_scripts": [
            "gh-workflow-flatten=main:main"
        ]
    },
    author="Seu Nome",
    description="Plugin CLI para achatar workflows GitHub com preview e exportações.",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License"
    ],
    python_requires='>=3.7',
)