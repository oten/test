from graphviz import Digraph

def export_to_dot(tree, output_path="workflow_tree.dot"):
    """
    Exporta a árvore de workflows para um arquivo .dot com estilo ortogonal,
    nós retangulares e links clicáveis para GitHub.
    """
    dot = Digraph(comment="Workflow Tree", format='png')
    dot.attr(rankdir="LR", fontname="Courier", nodesep="0.8", splines="ortho")
    dot.attr('node', shape="rect", style="filled", fillcolor="#f0f0f0")

    seen_edges = set()

    for parent, children in tree.items():
        safe_parent = sanitize(parent)
        dot.node(safe_parent, label=shorten(parent), URL=make_github_url(parent), target="_blank")

        for child in children:
            safe_child = sanitize(child)
            dot.node(safe_child, label=shorten(child), URL=make_github_url(child), target="_blank")

            edge = (safe_parent, safe_child)
            if edge not in seen_edges:
                dot.edge(safe_parent, safe_child)
                seen_edges.add(edge)

    dot.save(filename=output_path)
    print(f"📄 Arquivo .dot com links gerado em: {output_path}")

def sanitize(s):
    return s.replace('"', '\"').replace("\n", " ")

def shorten(label, max_len=60):
    return (label[:max_len] + "...") if len(label) > max_len else label

def make_github_url(label):
    """
    Constrói uma URL aproximada para o arquivo de workflow no GitHub.
    Espera formato: owner/repo/...@ref
    """
    if "@" not in label or "/" not in label:
        return ""
    parts = label.split("/")
    if len(parts) < 4:
        return ""
    owner, repo = parts[0], parts[1]
    filename_ref = parts[-1].split("@")
    if len(filename_ref) != 2:
        return ""
    filename, ref = filename_ref
    return f"https://github.com/{owner}/{repo}/blob/{ref}/.github/workflows/{filename}"