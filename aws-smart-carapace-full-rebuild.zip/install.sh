#!/bin/bash
go build -o aws-smart
echo 'eval "$(./aws-smart _carapace)"' >> ~/.bashrc
echo 'Reinicie o terminal ou execute: source ~/.bashrc'
