package cmd
import (
    "os"
    "os/exec"
    "github.com/rsteube/carapace"
    "github.com/spf13/cobra"
)
var rootCmd = &cobra.Command{
    Use: "aws", DisableFlagParsing: true,
    Run: func(cmd *cobra.Command, args []string) {
        aws := exec.Command("aws", args...)
        aws.Stdout = os.Stdout
        aws.Stderr = os.Stderr
        aws.Stdin = os.Stdin
        _ = aws.Run()
    },
}
func Execute() {
    carapace.Gen(rootCmd).Standalone()
    rootCmd.Execute()
}
