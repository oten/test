package main
import "aws-smart-carapace-full-rebuild/cmd"
func main() { cmd.Execute() }
