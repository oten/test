#!/bin/bash
GROUPS_FILE="$(dirname "$0")/config/groups.json"
[ -z "$1" ] && echo "Uso: $0 <nome-do-grupo>" && exit 1
GROUP_NAME="$1"
GROUP_BLOCK=$(jq -r --arg name "$GROUP_NAME" '.[$name]' "$GROUPS_FILE")
[ "$GROUP_BLOCK" == "null" ] && echo "Grupo '$GROUP_NAME' não encontrado." && exit 1
COMMANDS=$(jq -r --arg name "$GROUP_NAME" '.[$name].commands[] | @base64' "$GROUPS_FILE")
declare -A VARS
for CMD_B64 in $COMMANDS; do
  CMD=$(echo "$CMD_B64" | base64 --decode)
  NAME=$(echo "$CMD" | jq -r '.name')
  RAW_CMD=$(echo "$CMD" | jq -r '.cmd')
  OUTPUT_VAR=$(echo "$CMD" | jq -r '.output_to // empty')
  for KEY in "${!VARS[@]}"; do RAW_CMD=${RAW_CMD//\$$KEY/${VARS[$KEY]}}; done
  echo "🔹 Executando [$NAME]: $RAW_CMD"
  OUTPUT=$(eval "$RAW_CMD")
  [ -n "$OUTPUT_VAR" ] && VARS[$OUTPUT_VAR]="$OUTPUT" && echo "  ↪ $OUTPUT_VAR='$OUTPUT'"
done
