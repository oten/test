import os
import argparse
from pathlib import Path
from main import main as flatten_main
from cli import parse_args

def run_batch_from_file(repo_list_file, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(repo_list_file, 'r') as f:
        repos = [line.strip() for line in f if line.strip()]

    index_entries = []

    for repo in repos:
        print(f"🔍 Processando: {repo}")
        repo_name = repo.replace("/", "_")
        repo_out_dir = output_dir / repo_name
        repo_out_dir.mkdir(parents=True, exist_ok=True)

        args = [
            repo,
            "--output", str(repo_out_dir / "resolved.yml"),
            "--dot", str(repo_out_dir / "graph.dot"),
            "--html", str(repo_out_dir / "tree.html")
        ]

        # Simular sys.argv
        import sys
        old_argv = sys.argv
        sys.argv = ["gh-workflow-flatten"] + args
        try:
            flatten_main()
        finally:
            sys.argv = old_argv

        # Gerar SVG a partir do .dot
        dot_file = repo_out_dir / "graph.dot"
        svg_file = repo_out_dir / "graph.svg"
        os.system(f"dot -Tsvg {dot_file} -o {svg_file}")

        index_entries.append(f"<li><a href='{repo_name}/index.html'>{repo}</a><br><img src='{repo_name}/graph.svg' width='400'></li>")

        # Criar página individual
        with open(repo_out_dir / "index.html", "w") as f:
            f.write(f"""<!DOCTYPE html>
<html>
<head><meta charset='utf-8'><title>{repo}</title></head>
<body>
<h2>{repo}</h2>
<object type='image/svg+xml' data='graph.svg' width='100%'></object>
<iframe src='tree.html' width='100%' height='600'></iframe>
</body></html>
""")

    # Criar índice principal
    with open(output_dir / "index.html", "w") as f:
        f.write(f"""<!DOCTYPE html>
<html><head><meta charset='utf-8'><title>Workflow Index</title></head>
<body>
<h1>📚 Índice de Repositórios</h1>
<ul>
{chr(10).join(index_entries)}
</ul>
</body></html>
""")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo_list", help="Arquivo com a lista de caminhos de repositórios locais")
    parser.add_argument("--output", "-o", default="output", help="Diretório de saída")
    args = parser.parse_args()

    run_batch_from_file(args.repo_list, args.output)